# AICTE_Internship_2025
All the AICTE Internship taught will be put here for students
